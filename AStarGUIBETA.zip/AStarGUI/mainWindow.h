#pragma once

#include <QtWidgets/QMainWindow>

#include "mapViewer.h"
#include "ui_mainWindow.h"

class mainWindow : public QMainWindow
{
    Q_OBJECT

public:
    mainWindow(QWidget *parent = nullptr);
    ~mainWindow();
private slots:
    void on_generateButton_clicked();
    void on_buttonFileDialog_clicked();
    void onCellClicked(int x, int y);

private:
    Ui::mainWindowClass ui;
    mapViewer* map = nullptr;
};
