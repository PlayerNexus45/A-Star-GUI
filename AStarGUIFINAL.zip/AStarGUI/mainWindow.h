#pragma once

#include <QtWidgets/QMainWindow>

#include "mapViewer.h"
#include "ui_mainWindow.h"

class mainWindow : public QMainWindow
{
    Q_OBJECT
    /**
     * @brief Główne okno programu
     */
public:
    mainWindow(QWidget *parent = nullptr);
    ~mainWindow();
private slots:
    ///Funkcja wywołująca się przy kliknęciu przycisku "Generate"
    void on_generateButton_clicked();
    ///Funkcja otwierająca okno pozwalające na wybranie pliku
    void on_buttonFileDialog_clicked();
    ///Funkja wywołująca się przy kliknięciu komórki w Map Viewer
    void onCellClicked(int x, int y);

private:
    Ui::mainWindowClass ui;
    ///
    mapViewer* map = nullptr;
    QString filename;
};
