#include "mapViewer.h"
#include<qpainter.h>
#include<qfile.h>
#include<Qwheelevent>
#include<QMouseEvent>

mapViewer::mapViewer(QWidget* parent)
    : QMainWindow(parent)
{
    loadMap();
    resize(mapSize());
}
///Funkcja ładuje z pliku aktualny stan mapy i przekazuje go lokalnej zmiennej mapData
void mapViewer::loadMap() {
    QFile mapFile("map.txt");
    if (mapFile.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QTextStream in(&mapFile);
        while (!in.atEnd())
        {
            mapData.append(in.readLine());
        }
    }
}
///Funkcja rysuje w oknie stan mapy z lokalnej zmiennej mapData
void mapViewer::paintEvent(QPaintEvent*) {
    QPainter painter(this);
    painter.setPen(Qt::black);
    for (int y = 0; y < mapData.size(); y++)
    {
        QString line = mapData[y];
        for (int x = 0; x < line.length(); x++)
        {
            QRect rect(x * cellSize, y * cellSize, cellSize, cellSize);
            QChar c = line[x];
            if(QPoint(x, y) == start){
                painter.fillRect(rect, QColor("orange"));
            }
            else if(QPoint(x, y) == end){
                painter.fillRect(rect, QColor("aqua"));
            }
            else if (c == '.')
            {
                painter.fillRect(rect, Qt::darkGray);
            }
            else if (c == '@') {
                painter.fillRect(rect, Qt::black);
            }
            else if (c == '#') {
                painter.fillRect(rect, Qt::green);
            }
            painter.drawRect(rect);
        }
    }
}
///Funkcja przekazuje dane współrzędnych komórki klikniętej przez użytkownika
void mapViewer::mousePressEvent(QMouseEvent* event){
    QPoint pixelPos = event->pos();
    int gridX = pixelPos.x()/cellSize;
    int gridY = pixelPos.y()/cellSize;
    QString line = mapData[gridY];
    QChar clicked = line[gridX];
    if(gridY >= 0 && gridY <mapData.size() && gridX >= 0 && gridX < mapData[gridY].length() && clicked != QChar('@')){
        emit cellClicked(gridX, gridY);
    }
}
///Funkcja aktualizuje okno mapy poprzez wyczyszczenie lokalnej zmiennej mapData oraz załadowaniu ponownie mapy z pliku
void mapViewer::updateMap(){
    mapData.clear();
    loadMap();
    update();
}
///Funkcja powiększa oraz zmniejsza mapę po scrollowaniu użytkownika
void mapViewer::wheelEvent(QWheelEvent* event) {
    int delta = event->angleDelta().y();
    if (delta > 0 && cellSize < maxCellSize)
    {
        cellSize += 2;
    }
    else if (delta < 0 && cellSize > minCellSize)
    {
        cellSize -= 2;
    }
    updateSize();
    update();
}
///Funkcja dostosowywuje rozmiar okna do aktualnej mapy
QSize mapViewer::mapSize() {
    int w = mapData.isEmpty() ? 400 : mapData[0].length() * cellSize;
    int h = mapData.size() * cellSize;
    return QSize(w, h);
}
///Funkcja aktualizuje rozmiar mapy
void mapViewer::updateSize() {
    setMinimumSize(mapSize());
    resize(mapSize());
}
///Funkcja ustawia lokalną zmienną punktu startowego
void mapViewer::setStart(int x, int y){
    start = QPoint(x, y);
    update();
}
///Funkcja ustawia lokalną zmienną punktu końcowego
void mapViewer::setEnd(int x, int y){
    end = QPoint(x, y);
    update();
}
mapViewer::~mapViewer()
{}
