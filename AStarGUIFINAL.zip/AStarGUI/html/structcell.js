var structcell =
[
    [ "c", "structcell.html#a92ad19066b478c6cb5d5b852a9a93816", null ],
    [ "f", "structcell.html#a28060878a43d7ed4f36eb3cf5899cd74", null ],
    [ "g", "structcell.html#ab86275d3e9c1f74231dc8a46ac8bac7c", null ],
    [ "parentX", "structcell.html#a4490ba396ef0ebec447b972535faf23f", null ],
    [ "parentY", "structcell.html#a3168ba995074bfe7396f0393c2735e38", null ],
    [ "visited", "structcell.html#ae38ac184c8fc91c8ab4bcd879f8a363d", null ],
    [ "x", "structcell.html#a7c75a3656f94059da9e26a7ff2cdf75e", null ],
    [ "y", "structcell.html#a44df3882d06057fef0e7f480a45e4894", null ]
];