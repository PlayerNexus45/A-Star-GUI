var searchData=
[
  ['visited_0',['visited',['../structcell.html#ae38ac184c8fc91c8ab4bcd879f8a363d',1,'cell']]]
];
