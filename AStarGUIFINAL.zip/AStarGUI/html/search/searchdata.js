var indexSectionsWithContent =
{
  0: "acdefghilmprsuvwxy~",
  1: "cm",
  2: "am",
  3: "acdeghilmprsuw~",
  4: "cfgpvwxy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Pliki",
  3: "Funkcje",
  4: "Zmienne"
};

