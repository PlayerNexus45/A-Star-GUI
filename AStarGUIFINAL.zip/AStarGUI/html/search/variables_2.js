var searchData=
[
  ['g_0',['g',['../structcell.html#ab86275d3e9c1f74231dc8a46ac8bac7c',1,'cell']]]
];
