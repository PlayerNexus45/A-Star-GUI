var searchData=
[
  ['y_0',['y',['../structcell.html#a44df3882d06057fef0e7f480a45e4894',1,'cell']]]
];
