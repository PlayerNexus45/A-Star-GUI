var searchData=
[
  ['parentx_0',['parentX',['../structcell.html#a4490ba396ef0ebec447b972535faf23f',1,'cell']]],
  ['parenty_1',['parentY',['../structcell.html#a3168ba995074bfe7396f0393c2735e38',1,'cell']]]
];
