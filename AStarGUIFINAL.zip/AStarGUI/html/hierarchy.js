var hierarchy =
[
    [ "cell", "structcell.html", null ],
    [ "MinHeap", "class_min_heap.html", null ],
    [ "MinHeapG", "class_min_heap_g.html", null ],
    [ "QMainWindow", null, [
      [ "mainWindow", "classmain_window.html", null ],
      [ "mapViewer", "classmap_viewer.html", null ]
    ] ]
];