    /**
     * @brief Struktura komórki
     * Struktura cell pozwala na przechowywanie wszystkich danych komórki w jednym miejscu
     */
struct cell {

    ///Współrzędna X komórki na siatce
    int x,
        ///Współrzędna Y komórki na siatce
        y,
        ///Współrzędna X komórki poprzedzającej, na najkrótszej trasie
        parentX,
        ///Współrzędna Y komórki poprzedzającej, na najkrótszej trasie
        parentY;
    ///Znak komórki który definiuje jej funkcje (Ściana, wolna przestrzeń)
	char c;
    ///Suma G oraz odległości od celu
    double f,
        ///Odległość komórki od punktu startowego
        g;
    ///Czy komórka była już wcześniej odwiedzona podczas generowania ścieżki
	bool visited;
};
/**
     * @brief Stos
     */
class MinHeap {
    ///Tablica stosu
    cell* heapArray;
    ///Pojemność stosu
    int capacity;
    ///Ilość elementów na stosie
    int heapSize;
public:
	MinHeap(int capacity) {
		this->heapSize = 0;
		this->capacity = capacity;
		this->heapArray = new cell[capacity];
	}
    ///Utrzymanie struktury stosu, poprzez zachowania elementu z najmniejszym F na początku
	void MinHeapify(int i) {
		int l = left(i);
		int r = right(i);

		int smallest = i;
		if (l<heapSize && heapArray[l].f < heapArray[i].f)
		{
			smallest = l;
		}
		if (r<heapSize && heapArray[r].f < heapArray[smallest].f)
		{
			smallest = r;
		}
		if (smallest != i)
		{
			swap(heapArray[i], heapArray[smallest]);

			MinHeapify(smallest);
		}
	}
    ///Zamienia ze sobą dwa elementy
	void swap(cell &element1, cell &element2) {
		cell temp = element1;
		element1 = element2;
		element2 = temp;
	}
    ///Zwraca indeks elementu poprzedzającego element o indeksie i
	int parent(int i) { return (i-1)/2; }
    ///Zwraca indeks elementu po lewej stronie elementu o indeksie i
	int left(int i) { return (2 * i + 1); }
    ///Zwraca indeks elementu po prawej stronie elementu o indeksie i
	int right(int i) { return (2 * i + 2); }
    ///Zwraca element stosu o najmniejszej wartości F
	cell extractMin() {
		if (heapSize <= 0)
		{
			return {0, 0, 0, 0, 'n', 0.0, 0.0};
		}
		if (heapSize == 1)
		{
			heapSize--;
			return heapArray[0];
		}
		cell root = heapArray[0];
		heapArray[0] = heapArray[heapSize - 1];
		heapSize--;
		MinHeapify(0);

		return root;
	}
    ///Wstawia na stos komórkę k, jeśli stos nie ma już miejsca stos zostaje powiększony dwukrotnie (podobnie jak vector z biblioteki STL)
	void insertKey(cell k) {
		if (heapSize == capacity)
		{
			cell* temp = new cell[2 * capacity];
			for (int i = 0; i < capacity; i++)
			{
				temp[i] = heapArray[i];
			}
			delete[] heapArray;
			capacity *= 2;
			heapArray = temp;
		}

		int i = heapSize;
		heapArray[heapSize++] = k;
		while (i!=0 && heapArray[parent(i)].f > heapArray[i].f)
		{
			swap(heapArray[i], heapArray[parent(i)]);
			i = parent(i);
		}
	}
    ///Sprawdza czy element lf znajduje się na stosie
	bool isInHeap(cell lf) {
		for (int i = 0; i < heapSize; i++)
		{
			cell current = heapArray[i];
			if (current.x == lf.x && current.y == lf.y)
			{
				return true;
			}
		}
		return false;
	}
    ///Zwraca ile elementów jest na stosie
	int getSize() {
		return heapSize;
	}
    ///Usuwa tablicę dynamiczną stosu
	void deleteHeap() {
		delete[] heapArray;
	}

};
/**
     * @brief Stos sortujący po wartości G komórki
     */
class MinHeapG {
    ///Tablica stosu
    cell* heapArray;
    ///Pojemność stosu
    int capacity;
    ///Ilość elementów na stosie
    int heapSize;
public:
	MinHeapG(int capacity) {
		this->heapSize = 0;
		this->capacity = capacity;
		this->heapArray = new cell[capacity];
	}
    ///Utrzymanie struktury stosu, poprzez zachowania elementu z najmniejszym G na początku
	void MinHeapify(int i) {
		int l = left(i);
		int r = right(i);

		int smallest = i;
		if (l < heapSize && heapArray[l].g < heapArray[i].g)
		{
			smallest = l;
		}
		if (r < heapSize && heapArray[r].g < heapArray[smallest].g)
		{
			smallest = r;
		}
		if (smallest != i)
		{
			swap(heapArray[i], heapArray[smallest]);

			MinHeapify(smallest);
		}
	}
    ///Zamienia ze sobą dwa elementy
    void swap(cell &element1, cell &element2) {
        cell temp = element1;
        element1 = element2;
        element2 = temp;
    }
    ///Zwraca indeks elementu poprzedzającego element o indeksie i
    int parent(int i) { return (i-1)/2; }
    ///Zwraca indeks elementu po lewej stronie elementu o indeksie i
    int left(int i) { return (2 * i + 1); }
    ///Zwraca indeks elementu po prawej stronie elementu o indeksie i
    int right(int i) { return (2 * i + 2); }
    ///Zwraca element stosu o najmniejszej wartości F
    cell extractMin() {
        if (heapSize <= 0)
        {
            return {0, 0, 0, 0, 'n', 0.0, 0.0};
        }
        if (heapSize == 1)
        {
            heapSize--;
            return heapArray[0];
        }
        cell root = heapArray[0];
        heapArray[0] = heapArray[heapSize - 1];
        heapSize--;
        MinHeapify(0);

        return root;
    }
     ///Wstawia na stos komórkę k, jeśli stos nie ma już miejsca stos zostaje powiększony dwukrotnie (podobnie jak vector z biblioteki STL)
	void insertKey(cell k) {
		if (heapSize == capacity)
		{
			cell* temp = new cell[2 * capacity];
			for (int i = 0; i < capacity; i++)
			{
				temp[i] = heapArray[i];
			}
			delete[] heapArray;
			capacity *= 2;
			heapArray = temp;
		}

		int i = heapSize;
		heapArray[heapSize++] = k;
		while (i != 0 && heapArray[parent(i)].g > heapArray[i].g)
		{
			swap(heapArray[i], heapArray[parent(i)]);
			i = parent(i);
		}
	}
    ///Zwraca ile elementów jest na stosie
    int getSize() {
        return heapSize;
    }
    ///Usuwa tablicę dynamiczną stosu
    void deleteHeap() {
        delete[] heapArray;
    }

};
