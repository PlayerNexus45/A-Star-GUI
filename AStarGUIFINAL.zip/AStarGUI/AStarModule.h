#include <iostream>
#include "MinHeap.h"
#include <fstream>
#include <cmath>
///Definicja ściany
const char WALL = '@';
///Definicja pustego miejsca
const char FREE = '.';

using namespace std;
///Funkcja zamienia tekstowy plik z rozszerzeniem ".map" na tablice dynamiczną struktury komórki
/// \param W szerokość mapy
cell** getGridFromMap(int& W, int& H, string filename);
///Funkcja przetwarza komórkę, nadając jej wartości G (Odległość od punktu początkowego) oraz H (odległość od celu) a następnie sumuje je aby otrzymać wartość F
void computeCellMinHeap(cell current, cell& neighor, cell end, MinHeap& pq);
///Funkcja rekonstruuje ścieżkę do celu, a następnie wypisuje ją do konsoli oraz zaznacza ścieżkę w tablicy dynamicznej
void reconstructPath(cell**& grid, cell end, int w, int h);
/// \brief Funkcja generująca ścieżkę z punktu (startX, startY) do punktu (endX, endY) w na podanej mapie
/**
  Algorytm A Star działa na zasadzie znajdywania komórki mapy której suma odległości od startu do niej (w komórce nazywana G) oraz odległości od celu jest najmniejsza (w komórce suma nazywana F)
Kolejne sprawdzane komórki przechowywane są w klasie MinHeap (po polsku zwana stosem), gdzie element z najmniejszą wartością F jest zawsze na pierwszej pozycji tablicy.
Stos pozwala nam na sortowanie elementów przy złożeniowości czasowej O(log(n)), w przeciwieństwie do sortowania typowej tablicy dynamicznej O(n^2). W testach różnica złożeniowości czasowej pozwoliła na wycięcie 1ms przy mapie 20x20.


**/
void aStar2(string filename, int startX, int startY, int endX, int endY);
///Funkcja zwraca dystans od komórki start do komórki end
double hDist(cell start, cell end);
///Funkcja zapisuje stan mapy z tablicy dynamicznej komórek
void saveToFile(cell** map, int W, int H);
