#pragma once

#include <QtWidgets/QMainWindow>
#include <qstringlist.h>
/**
     * @brief Okno na którym widoczna jest mapa
     */
class mapViewer : public QMainWindow
{
    Q_OBJECT

public:
    mapViewer(QWidget* parent = nullptr);
    ~mapViewer();
    void paintEvent(QPaintEvent*);
    void wheelEvent(QWheelEvent*);

    QSize mapSize();
    void loadMap();
    void updateSize();
    void updateMap();
    void setStart(int x, int y);
    void setEnd(int x, int y);
protected:
    void mousePressEvent(QMouseEvent* event)override;
private:
    QStringList mapData;
    const int minCellSize = 2;
    const int maxCellSize = 100;
    int cellSize = 20;

    QPoint start = {-1, -1};
    QPoint end = {-1, -1};
signals:
    void cellClicked(int x, int y);


};
